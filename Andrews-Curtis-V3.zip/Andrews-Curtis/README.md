# Andrews–Curtis Conjecture — Computational Attack (V3)

**Status (2026-07-20):** AK(3) still open. Pure beam search with correct cyclic substitution super-moves + Booth canonical form makes no length progress past the starting length 13 on the standard presentation (1.3 M+ states explored). Myasnikov example solves cleanly → implementation is correct; the instance is hard.

## What this repo contains

```
src/ac_solver_v3.py     # Full solver (Presentation + 12-rule + cyclic SUBST + Booth + beam)
tests/                  # Quick sanity checks
docs/research_notes.md  # Distilled findings from the literature review
results/                # JSON dumps of every run
scripts/                # Convenience launchers
```

## Key algorithmic ingredients (all from the 2024–2026 literature)

| Component | Source | Effect |
|-----------|--------|--------|
| Cyclic-rotation substitution super-move | Fagan et al. (Caltech / ICML-adjacent 2026) | Macro that realises many primitive AC steps at once; validity = forced cancellation |
| Booth minimal cyclic rotation | classical + used heavily in recent AC papers | ~1600× reduction of the state space |
| 12-rule action space | Lisitsa 2025 / Shehper et al. | Exactly the moves used in the ATP encodings that produced the (later retracted) stable result |
| Generator Nielsen moves | classical | Essential for the known short paths on Myasnikov-type examples |
| Proper total order on letters | this repo | Fixes the classic bug that made `[1],[2]` look non-standard after inversion |

## Quick start

```bash
# sanity — must find a short path
python -m src.ac_solver_v3 myasnikov --beam 200 --depth 40 --timeout 60

# the real target
python -m src.ac_solver_v3 ak3 --beam 800 --depth 250 --states 12000000 --timeout 7200
```

## Current experimental picture

- Clean 12-rule + Nielsen beam (no super-moves) on AK(3): depth 150, ~1.5 M states, best length never drops below 13.
- With correct cyclic super-moves: same qualitative behaviour — the search explores many length-preserving or length-increasing states but never finds a descent.
- This matches the folklore that any AC path for AK(3), if it exists, is either extremely long or requires a temporary length explosion that pure length-based beam search cannot tolerate.

## Next logical attacks (ordered by expected value)

1. **Better scoring / potential** — replace pure length by a learned or hand-crafted potential that rewards “progress toward free reduction” or counts cancellable pairs after all cyclic conjugates.
2. **Genetic / population-based search** — maintain a population of presentations and use crossover on relator pairs; the Caltech RL agents essentially discovered super-moves this way.
3. **MS-equivalent presentation** (`ms_ak3`) and the long bridge presentation P — both are AC-equivalent (or stably equivalent) and may have shorter paths under the 12-rule system.
4. **Macro learning** — run short beam searches from many random 2-generator balanced presentations, collect successful short paths, turn the frequent sub-sequences into new super-moves, then re-attack AK(3).
5. **Stable AC** — allow stabilisation (add a free generator + relator) and later de-stabilise; the retracted claim used this route.

## Citation / provenance

All algorithmic ideas are taken from the public literature (Fagan+, Lisitsa, Shehper, Myasnikov, Ivanov, Lackenby). The concrete implementation and the careful total-order fix are original to this repository.
