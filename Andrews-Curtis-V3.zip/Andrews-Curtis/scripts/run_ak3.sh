#!/usr/bin/env bash
# Launch a serious AK(3) search (adjust resources as needed)
set -euo pipefail
cd "$(dirname "$0")/.."
python -m src.ac_solver_v3 ak3 \
  --beam 1000 \
  --depth 300 \
  --states 15000000 \
  --timeout 10800
