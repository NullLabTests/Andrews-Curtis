#!/usr/bin/env python3
"""Minimal sanity checks for the V3 solver."""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from ac_solver_v3 import (
    Presentation,
    example_myasnikov,
    example_ak3,
    cyclic_canonical,
    free_reduce,
    ACBeamSearcherV3,
)


def test_standard_trivial_detected():
    p = Presentation.trivial(2)
    assert p.is_standard_trivial(), "standard trivial not recognised"
    assert p.is_solved()
    print("✓ standard trivial detection")


def test_cyclic_canonical_prefers_positive():
    # single positive letter must stay positive
    assert cyclic_canonical([1]) == [1]
    assert cyclic_canonical([-1]) == [1]          # inverse is flipped
    assert cyclic_canonical([2]) == [2]
    assert cyclic_canonical([-2]) == [2]
    print("✓ cyclic_canonical total order")


def test_myasnikov_solves_quickly():
    """Must find a path; depth bound is generous."""
    pres = example_myasnikov()
    searcher = ACBeamSearcherV3(
        beam_width=300,
        max_depth=40,
        max_states=200_000,
        timeout=90.0,
        use_substitution_moves=True,
        use_generator_moves=True,
        verbose=False,
        results_dir="/tmp/ac_test_results",
    )
    found, path, stats = searcher.search(pres, run_id="test_myasnikov")
    assert found, f"Myasnikov not solved: {stats}"
    assert path is not None and len(path) > 0
    print(f"✓ Myasnikov solved in {stats['depth']} steps ({stats['states_explored']} states)")


def test_ak3_starts_correctly():
    p = example_ak3()
    assert p.total_length() == 13
    assert not p.is_solved()
    print("✓ AK(3) presentation correct")


if __name__ == "__main__":
    test_standard_trivial_detected()
    test_cyclic_canonical_prefers_positive()
    test_ak3_starts_correctly()
    test_myasnikov_solves_quickly()
    print("\nAll basic tests passed.")
