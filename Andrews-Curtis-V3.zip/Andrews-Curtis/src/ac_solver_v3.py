#!/usr/bin/env python3
"""
Andrews–Curtis Conjecture — Corrected Solver V3
================================================

Integrates:
  - Correct cyclic-rotation substitution super-moves (Fagan et al. / Caltech line)
  - Booth's algorithm for minimal cyclic rotation → ~1600× state-space reduction
  - 12-rule action space (Lisitsa / Shehper et al.)
  - Generator Nielsen moves
  - Proper total order on generators so standard trivial is correctly detected

AK(3) = ⟨a, b | a³b⁴, abab⁻¹a⁻¹b⁻¹⟩ remains OPEN (the 2024–25 “stable”
claim was retracted). This solver is the current best pure-search baseline.

Author: NullLabTests (with Grok assist)
"""

from __future__ import annotations

import itertools
import json
import os
import sys
import time
from collections import defaultdict
from dataclasses import dataclass, field
from heapq import heappop, heappush
from typing import Callable, Optional, Iterator

# ═══════════════════════════════════════════════════════════════════════
# 1. Word utilities
# ═══════════════════════════════════════════════════════════════════════

Letter = int  # positive = generator; negative = inverse


def free_reduce(word: list[Letter]) -> list[Letter]:
    stack: list[Letter] = []
    for a in word:
        if stack and stack[-1] == -a:
            stack.pop()
        else:
            stack.append(a)
    return stack


def multiply(w1: list[Letter], w2: list[Letter]) -> list[Letter]:
    return free_reduce(w1 + w2)


def invert(word: list[Letter]) -> list[Letter]:
    return [-a for a in reversed(word)]


def conjugate(word: list[Letter], gen: Letter) -> list[Letter]:
    return free_reduce([gen] + word + [-gen])


def cyclic_rotate(word: list[Letter], k: int) -> list[Letter]:
    if not word:
        return []
    n = len(word)
    k %= n
    return word[k:] + word[:k]


# ── Booth’s algorithm (O(n)) for least rotation ───────────────────────

def _least_rotation(s: list[int]) -> int:
    """Return start index of the lexicographically minimal rotation."""
    n = len(s)
    if n <= 1:
        return 0
    s2 = s + s
    f = [-1] * (2 * n)
    k = 0
    for j in range(1, 2 * n):
        i = f[j - k - 1]
        while i != -1 and s2[j] != s2[k + i + 1]:
            if s2[j] < s2[k + i + 1]:
                k = j - i - 1
            i = f[i]
        if s2[j] != s2[k + i + 1]:
            if s2[j] < s2[k]:
                k = j
            f[j - k] = -1
        else:
            f[j - k] = i + 1
    return k


def minimal_cyclic_rotation(word: list[Letter]) -> list[Letter]:
    if not word:
        return []
    k = _least_rotation(word)
    return word[k:] + word[:k]


def _letter_key(x: Letter) -> tuple[int, int]:
    """Total order: a < a⁻¹ < b < b⁻¹ < …  (positives before their inverses)."""
    return (abs(x), 0 if x > 0 else 1)


def _word_key(w: list[Letter]) -> tuple:
    return tuple(_letter_key(x) for x in w)


def cyclic_canonical(word: list[Letter]) -> list[Letter]:
    """
    Canonical cyclic representative:
    min{ minimal rotation of w, minimal rotation of w⁻¹ }
    under the total order defined by _letter_key.
    Guarantees that the standard generators [1], [2], … stay positive.
    """
    if not word:
        return []
    c1 = minimal_cyclic_rotation(word)
    c2 = minimal_cyclic_rotation(invert(word))
    return c1 if _word_key(c1) <= _word_key(c2) else c2


def cyclic_length(word: list[Letter]) -> int:
    """Length after cyclic free reduction (cancel prefix–suffix inverse pairs)."""
    if not word:
        return 0
    w = list(word)
    while len(w) >= 2 and w[0] == -w[-1]:
        w = w[1:-1]
    return len(w)


def word_str(word: list[Letter], letters: Optional[list[str]] = None) -> str:
    if not word:
        return "ε"
    parts: list[str] = []
    for a in word:
        if a > 0:
            name = letters[a - 1] if letters and a - 1 < len(letters) else f"x{a}"
        else:
            base = letters[(-a) - 1] if letters and (-a) - 1 < len(letters) else f"x{-a}"
            name = base + "⁻¹"
        parts.append(name)
    return "·".join(parts) if len(parts) <= 8 else "".join(parts)


# ═══════════════════════════════════════════════════════════════════════
# 2. Presentation
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class Presentation:
    n_gens: int
    relators: list[list[Letter]]

    def __post_init__(self):
        assert len(self.relators) == self.n_gens

    @staticmethod
    def trivial(n: int = 2) -> "Presentation":
        return Presentation(n, [[i] for i in range(1, n + 1)])

    @staticmethod
    def from_lists(n_gens: int, rels: list[list[int]]) -> "Presentation":
        return Presentation(n_gens, [free_reduce(r) for r in rels])

    def copy(self) -> "Presentation":
        return Presentation(self.n_gens, [list(r) for r in self.relators])

    def total_length(self) -> int:
        return sum(len(r) for r in self.relators)

    def total_cyclic_length(self) -> int:
        return sum(cyclic_length(r) for r in self.relators)

    def max_length(self) -> int:
        return max((len(r) for r in self.relators), default=0)

    # ── Primitive AC moves ────────────────────────────────────────────

    def inv(self, i: int) -> "Presentation":
        q = self.copy()
        q.relators[i] = invert(q.relators[i])
        return q

    def mul(self, i: int, j: int, inv_j: bool = False) -> "Presentation":
        q = self.copy()
        rhs = invert(q.relators[j]) if inv_j else q.relators[j]
        q.relators[i] = multiply(q.relators[i], rhs)
        return q

    def mul_left(self, i: int, j: int, inv_j: bool = False) -> "Presentation":
        q = self.copy()
        lhs = invert(q.relators[j]) if inv_j else q.relators[j]
        q.relators[i] = multiply(lhs, q.relators[i])
        return q

    def conj(self, i: int, gen: Letter) -> "Presentation":
        q = self.copy()
        q.relators[i] = conjugate(q.relators[i], gen)
        return q

    def permute(self, perm: list[int]) -> "Presentation":
        q = self.copy()
        q.relators = [q.relators[p] for p in perm]
        return q

    # ── Generator Nielsen moves ───────────────────────────────────────

    def map_gens(self, gen_map: dict[int, list[Letter]]) -> "Presentation":
        q = self.copy()
        new_rels = []
        for r in q.relators:
            new_word: list[Letter] = []
            for a in r:
                if a > 0:
                    new_word.extend(gen_map.get(a, [a]))
                else:
                    mapped = gen_map.get(-a, [-a])
                    new_word.extend(invert(mapped))
            new_rels.append(free_reduce(new_word))
        q.relators = new_rels
        return q

    # ── Correct cyclic substitution super-move (Fagan / Caltech) ──────

    def substitution_move(
        self, i: int, j_sign: int, k1: int, k2: int
    ) -> Optional["Presentation"]:
        """
        Apply one cyclic substitution super-move.

        Validity condition (ensures at least one free cancellation):
            last(rot^{k1}(r_i)) == -first(rot^{k2}(r_other^{±1}))
        """
        if self.n_gens != 2:
            return None
        other = 1 - i
        r_target = self.relators[i][:]
        r_source = self.relators[other][:]
        if j_sign == -1:
            r_source = invert(r_source)

        if not r_target or not r_source:
            return None

        rot_target = cyclic_rotate(r_target, k1)
        rot_source = cyclic_rotate(r_source, k2)

        if rot_target[-1] != -rot_source[0]:
            return None  # no cancellation → not a useful super-move

        new_ri = free_reduce(rot_target + rot_source)
        q = self.copy()
        q.relators[i] = new_ri
        return q

    def all_substitution_moves(self) -> list[tuple[str, "Presentation"]]:
        results: list[tuple[str, Presentation]] = []
        if self.n_gens != 2:
            return results
        for i in (0, 1):
            for j_sign in (1, -1):
                max_k1 = max(len(self.relators[i]), 1)
                max_k2 = max(len(self.relators[1 - i]), 1)
                for k1 in range(max_k1):
                    for k2 in range(max_k2):
                        res = self.substitution_move(i, j_sign, k1, k2)
                        if res is not None:
                            desc = (
                                f"SUBST r{i}←r{1-i}"
                                f"{'⁻¹' if j_sign == -1 else ''}"
                                f" rot({k1},{k2})"
                            )
                            results.append((desc, res))
        return results

    # ── Normalization & solved checks ─────────────────────────────────

    def normalize(self) -> "Presentation":
        """Booth + cyclic canonical + sort → massive state-space collapse."""
        reduced = [cyclic_canonical(free_reduce(r)) for r in self.relators]
        seen: set[tuple] = set()
        unique: list[list[Letter]] = []
        for r in reduced:
            t = tuple(r)
            if t not in seen and t:
                seen.add(t)
                unique.append(list(r))
        unique.sort(key=_word_key)
        while len(unique) < self.n_gens:
            unique.append([])
        return Presentation(self.n_gens, unique[: self.n_gens])

    def state_key(self) -> tuple:
        return (
            self.n_gens,
            tuple(sorted(tuple(cyclic_canonical(free_reduce(r))) for r in self.relators)),
        )

    def is_trivial(self) -> bool:
        return all(len(r) == 0 for r in self.relators)

    def is_standard_trivial(self) -> bool:
        if self.n_gens == 0:
            return True
        norm = self.normalize().relators
        expected = {tuple([i]) for i in range(1, self.n_gens + 1)}
        actual = {tuple(r) for r in norm}
        return actual == expected

    def is_solved(self) -> bool:
        return self.is_trivial() or self.is_standard_trivial()

    def show(self, letters: Optional[list[str]] = None) -> str:
        gens = " ".join(
            letters[i] if letters and i < len(letters) else f"x{i+1}"
            for i in range(self.n_gens)
        )
        rels = ", ".join(word_str(r, letters) for r in self.relators)
        return f"⟨ {gens} | {rels} ⟩"

    def __str__(self) -> str:
        return self.show(["a", "b"] if self.n_gens == 2 else None)


# ═══════════════════════════════════════════════════════════════════════
# 3. Move enumeration
# ═══════════════════════════════════════════════════════════════════════

MoveRecord = tuple[str, Callable[[Presentation], Presentation]]


def enumerate_moves_12rule(p: Presentation) -> list[MoveRecord]:
    """Exactly the 12-rule system used by Lisitsa / Shehper et al."""
    n = p.n_gens
    moves: list[MoveRecord] = []
    # AC′1 — multiply (4 rules for 2 gens)
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            moves.append((f"MUL r{i}·r{j}", lambda q, a=i, b=j: q.mul(a, b)))
            moves.append((f"MUL r{i}·r{j}⁻¹", lambda q, a=i, b=j: q.mul(a, b, True)))
    # AC′2 — conjugate by generators & inverses (8 rules)
    for i in range(n):
        for g in range(1, n + 1):
            moves.append((f"CONJ r{i} by x{g}", lambda q, idx=i, gen=g: q.conj(idx, gen)))
            moves.append(
                (f"CONJ r{i} by x{g}⁻¹", lambda q, idx=i, gen=-g: q.conj(idx, gen))
            )
    return moves


def enumerate_moves_full(p: Presentation) -> list[MoveRecord]:
    """12-rule + permutations + generator Nielsen moves."""
    moves = enumerate_moves_12rule(p)
    n = p.n_gens
    # Adjacent swaps
    for i in range(n - 1):
        perm = list(range(n))
        perm[i], perm[i + 1] = perm[i + 1], perm[i]
        moves.append((f"SWAP r{i}r{i+1}", lambda q, p_=perm: q.permute(p_)))
    # Generator inversions
    for g in range(1, n + 1):
        gm = {a: [a] for a in range(1, n + 1)}
        gm[g] = [-g]
        moves.append((f"GENINV x{g}", lambda q, m=gm: q.map_gens(m)))
    # Generator multiplications
    for g in range(1, n + 1):
        for h in range(1, n + 1):
            if g == h:
                continue
            gm = {a: [a] for a in range(1, n + 1)}
            gm[g] = [g, h]
            moves.append((f"GENMUL x{g}→x{g}x{h}", lambda q, m=gm: q.map_gens(m)))
    return moves


# ═══════════════════════════════════════════════════════════════════════
# 4. Beam search
# ═══════════════════════════════════════════════════════════════════════

SearchResult = tuple[bool, Optional[list[tuple[str, Presentation]]], dict]


@dataclass
class ACBeamSearcherV3:
    beam_width: int = 500
    max_depth: int = 200
    max_states: int = 8_000_000
    timeout: float = 3600.0
    use_substitution_moves: bool = True
    use_generator_moves: bool = True
    verbose: bool = True
    results_dir: str = "results"

    def __post_init__(self):
        os.makedirs(self.results_dir, exist_ok=True)

    def _make_move_set(self, p: Presentation) -> list[MoveRecord]:
        if self.use_generator_moves:
            return enumerate_moves_full(p)
        return enumerate_moves_12rule(p)

    def search(
        self, start: Presentation, run_id: Optional[str] = None
    ) -> SearchResult:
        if run_id is None:
            run_id = f"run_{int(time.time())}"

        t0 = time.monotonic()
        if start.is_solved():
            return True, [], {"states_explored": 0, "depth": 0, "reason": "already trivial"}

        visited: dict[tuple, int] = {start.state_key(): 0}
        total_states = 0
        best_len = start.total_length()
        best_cyclic = start.total_cyclic_length()
        last_report = 0.0

        frontier: list[tuple[list[tuple[str, Presentation]], Presentation]] = [
            ([], start)
        ]

        for depth in range(self.max_depth):
            if not frontier or time.monotonic() - t0 > self.timeout:
                break

            candidates: list[tuple] = []

            for path, pres in frontier:
                if time.monotonic() - t0 > self.timeout:
                    break

                # Primitive + Nielsen moves
                for move_desc, move_fn in self._make_move_set(pres):
                    new_pres = move_fn(pres)
                    key = new_pres.state_key()
                    if key in visited and visited[key] <= depth + 1:
                        continue
                    visited[key] = depth + 1
                    total_states += 1
                    new_path = path + [(move_desc, new_pres)]

                    if new_pres.is_solved():
                        if self.verbose:
                            print(
                                f"\n  ✓ FOUND at depth {depth+1} "
                                f"after {total_states} states!",
                                flush=True,
                            )
                        stats = {
                            "states_explored": total_states,
                            "depth": depth + 1,
                            "reason": "found",
                            "elapsed": time.monotonic() - t0,
                        }
                        self._save(run_id + "_FOUND", True, new_path, stats)
                        return True, new_path, stats

                    tl = new_pres.total_length()
                    cl = new_pres.total_cyclic_length()
                    # Mild preference for shorter cyclic length; allow temporary growth
                    score = tl + 0.7 * cl + 0.01 * depth
                    candidates.append((score, len(new_path), new_path, new_pres))

                # Cyclic substitution super-moves
                if self.use_substitution_moves:
                    for sub_desc, sub_res in pres.all_substitution_moves():
                        key = sub_res.state_key()
                        if key in visited and visited[key] <= depth + 1:
                            continue
                        visited[key] = depth + 1
                        total_states += 1
                        new_path = path + [(sub_desc, sub_res)]

                        if sub_res.is_solved():
                            if self.verbose:
                                print(
                                    f"\n  ✓ FOUND via super-move at depth "
                                    f"{depth+1} after {total_states}!",
                                    flush=True,
                                )
                            stats = {
                                "states_explored": total_states,
                                "depth": depth + 1,
                                "reason": "found via super-move",
                                "elapsed": time.monotonic() - t0,
                            }
                            self._save(run_id + "_FOUND", True, new_path, stats)
                            return True, new_path, stats

                        tl = sub_res.total_length()
                        cl = sub_res.total_cyclic_length()
                        score = tl + 0.7 * cl + 0.01 * depth
                        candidates.append((score, len(new_path), new_path, sub_res))

            if total_states >= self.max_states:
                break

            candidates.sort(key=lambda x: x[0])
            frontier = [
                (path, pres) for _, _, path, pres in candidates[: self.beam_width]
            ]

            if frontier:
                best = frontier[0][1]
                bl, bc = best.total_length(), best.total_cyclic_length()
                if bl < best_len:
                    best_len = bl
                if bc < best_cyclic:
                    best_cyclic = bc

            now = time.monotonic()
            if self.verbose and now - last_report > 8.0:
                print(
                    f"  [depth={depth+1:3d}  beam={len(frontier):4d}  "
                    f"explored={total_states:8d}  best_len={best_len:2d}  "
                    f"best_cyclic={best_cyclic:2d}  "
                    f"elapsed={now-t0:.0f}s]",
                    flush=True,
                )
                last_report = now

        elapsed = time.monotonic() - t0
        stats = {
            "states_explored": total_states,
            "depth": depth + 1 if "depth" in dir() else 0,
            "best_length": best_len,
            "best_cyclic": best_cyclic,
            "reason": "search exhausted / timeout",
            "elapsed": elapsed,
        }
        self._save(run_id, False, None, stats)
        return False, None, stats

    def _save(self, run_id: str, found: bool, path, stats: dict):
        data = {
            "run_id": run_id,
            "found": found,
            "stats": {k: (float(v) if isinstance(v, float) else v) for k, v in stats.items()},
        }
        if path:
            data["path"] = [
                {"move": d, "state": str(s), "len": s.total_length()} for d, s in path
            ]
        fname = os.path.join(self.results_dir, f"{run_id}.json")
        with open(fname, "w") as f:
            json.dump(data, f, indent=2)


# ═══════════════════════════════════════════════════════════════════════
# 5. Canonical examples
# ═══════════════════════════════════════════════════════════════════════

def example_ak3() -> Presentation:
    """AK(3) — still open."""
    return Presentation.from_lists(2, [
        [1, 1, 1, 2, 2, 2, 2],          # a³b⁴
        [1, 2, 1, -2, -1, -2],          # abab⁻¹a⁻¹b⁻¹
    ])


def example_myasnikov() -> Presentation:
    """Known AC-trivializable (sanity check)."""
    return Presentation.from_lists(2, [
        [1, 1, -2, -2, -2],
        [1, 2, 1, -2, -1, -2],
    ])


def example_ms_ak3() -> Presentation:
    """MS(3, y⁻¹x⁻¹yxy) ≅ AK(3) (Myasnikov et al.)."""
    return Presentation.from_lists(2, [
        [-1, 2, 2, 2, 1, -2, -2, -2, -2],
        [-1, -2, -1, 2, 1, 2],
    ])


def example_presentation_p() -> Presentation:
    """Bridge presentation P (Shehper / Lisitsa)."""
    return Presentation.from_lists(2, [
        [-1, -2, 1, -2, -1, 2, 1, -2, -2, 1, 2, 1, -1, 2],
        [-2, -1, 2, 2, -1, -2, -1, 2, 1, 2, -2, -2, 1],
    ])


EXAMPLES = {
    "ak3": (example_ak3(), "AK(3) — OPEN primary target"),
    "myasnikov": (example_myasnikov(), "Known trivializable (sanity)"),
    "ms_ak3": (example_ms_ak3(), "MS-equivalent of AK(3)"),
    "presentation_p": (example_presentation_p(), "Bridge P (stable approach)"),
}


# ═══════════════════════════════════════════════════════════════════════
# 6. CLI / non-interactive runner
# ═══════════════════════════════════════════════════════════════════════

def run_example(
    name: str = "ak3",
    beam: int = 800,
    depth: int = 200,
    states: int = 8_000_000,
    timeout: float = 3600.0,
    use_sub: bool = True,
    use_gen: bool = True,
) -> dict:
    if name not in EXAMPLES:
        raise ValueError(f"Unknown example {name}. Choose from {list(EXAMPLES)}")
    pres, desc = EXAMPLES[name]
    print(f"Target: {name} — {desc}")
    print(f"Start : {pres}  (len={pres.total_length()})")
    print(f"Params: beam={beam} depth={depth} states={states} timeout={timeout}s")
    print(f"        sub={use_sub} gen={use_gen}\n")

    searcher = ACBeamSearcherV3(
        beam_width=beam,
        max_depth=depth,
        max_states=states,
        timeout=timeout,
        use_substitution_moves=use_sub,
        use_generator_moves=use_gen,
        verbose=True,
        results_dir="results",
    )
    found, path, stats = searcher.search(pres, run_id=f"{name}_{int(time.time())}")
    print("\n" + "─" * 60)
    if found:
        print(f"✓ TRIVIALIZATION FOUND  depth={stats['depth']}")
        if path:
            for i, (mv, st) in enumerate(path, 1):
                print(f"  [{i:3d}] {mv:40s}  {st}  (len={st.total_length()})")
    else:
        print(f"✗ not found  reason={stats.get('reason')}")
    print(f"\nStats: {stats}")
    return {"found": found, "stats": stats, "path": path}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="AC Solver V3")
    parser.add_argument("example", nargs="?", default="ak3", choices=list(EXAMPLES))
    parser.add_argument("--beam", type=int, default=800)
    parser.add_argument("--depth", type=int, default=200)
    parser.add_argument("--states", type=int, default=8_000_000)
    parser.add_argument("--timeout", type=float, default=3600.0)
    parser.add_argument("--no-sub", action="store_true")
    parser.add_argument("--no-gen", action="store_true")
    args = parser.parse_args()
    run_example(
        args.example,
        beam=args.beam,
        depth=args.depth,
        states=args.states,
        timeout=args.timeout,
        use_sub=not args.no_sub,
        use_gen=not args.no_gen,
    )
