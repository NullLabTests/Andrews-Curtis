# Research Notes — Andrews–Curtis, AK(3), and Computational Attacks (2024–2026)

## Status of AK(3)

- AK(n) = ⟨a,b | aⁿ bⁿ⁺¹ , a b a b⁻¹ a⁻¹ b⁻¹⟩
- AK(2) is trivial (easy).
- AK(3) is the smallest open case and has resisted every published computational attack.
- A 2024–25 claim of *stable* AC-trivializability of AK(3) (Shehper et al.) was based on an incorrect intermediate theorem and has been retracted. AK(3) is therefore still completely open in both the ordinary and the stable senses.

## Critical algorithmic facts extracted from the literature

### 1. Correct substitution super-move (Fagan et al.)

The naïve “delete a common substring” move is **not** an AC move.  
The correct macro is:

```
rotate r_i by k₁ positions
rotate r_j^{±1} by k₂ positions
require that the last letter of the first rotation cancels the first letter of the second
concatenate and free-reduce
```

This single operation is realizable by a (usually short) sequence of ordinary AC multiplications and conjugations, and is the one used by the successful RL agents.

### 2. Booth canonical form

For every relator keep only the lexicographically smallest among all its cyclic rotations and the rotations of its inverse.  
Under a sensible total order on the alphabet this collapses the state space by roughly three orders of magnitude (quoted 1600× in the recent papers).

### 3. 12-rule system

Exactly four multiplications + eight conjugations by the generators and their inverses.  
This is the action space used in the Prover9 encodings and in the (retracted) stable result. It is complete for the AC conjecture on two generators.

### 4. MS-equivalence

Myasnikov et al. (2002) showed  
AK(n) ≅_AC MS(n, y⁻¹ x⁻¹ y x y).  
The MS presentation is sometimes easier for automated search; it is included in the solver as `ms_ak3`.

### 5. Bridge presentation P

A longer (length ≈ 46) presentation that appears in the stable-AC literature.  
If one can AC-transform P into the trivial presentation, and also transform AK(3) into P (or vice versa), one obtains a proof. Both directions are still open.

## Why pure length beam search fails on AK(3)

All published successful trivializations of other balanced presentations (Myasnikov, etc.) go through intermediate states whose total length is *larger* than the start.  
A beam that only keeps the current shortest presentations therefore prunes the only paths that work.  
This is the central obstacle the next generation of search must overcome (potential functions, genetic algorithms, or learned macros).

## Recommended next experiments (ranked)

1. Genetic algorithm with length + cyclic-length multi-objective fitness and occasional stabilisation.
2. Offline macro mining: solve thousands of random easy instances, extract frequent short sequences, add them as new super-moves, re-attack AK(3).
3. Switch the primary target to the MS presentation or to presentation P.
4. Hybrid: short RL episodes that discover new super-moves, interleaved with classical beam search that uses the growing macro set.
